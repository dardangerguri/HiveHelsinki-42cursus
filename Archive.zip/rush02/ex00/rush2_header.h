/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush2_header.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jvuorenm <jvuorenm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 13:29:57 by jvuorenm          #+#    #+#             */
/*   Updated: 2022/07/17 17:17:05 by jvuorenm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef RUSH2_HEADER_H
# define RUSH2_HEADER_H
# include <stdlib.h>

void	ft_putnbr(int nb);
int		ft_strlen(char *str);
void	ft_putstr(char *str);
void	ft_putchar(char c);
int		validate_rush(char **pattern, int x, int y);
char	*ft_strcpy(char *src, char *dst);
char	*ft_fgets(char str[], int bytes);
char	**allocate_memory(char **pattern);
void	print_pattern(int y, char **pattern);
int		get_x(char *pattern);
void	print_rush_result(char *rush_name, int x, int y, int multiple);
int		*create_corner_arr(char **pattern, int x, int y);
int		cornertypes_consistent(int *types, int x, int y);
int		rush00_corners(int *types, int x, int y);
int		rush01_corners(int *types, int x, int y);
int		rush02_corners(int *types, int x, int y);
int		rush03_corners(int *types, int x, int y);
int		rush04_corners(int *types, int x, int y);
int		identify_rush(char **pattern, int x, int y);
int		check_corners(int *types, int x, int y);
int		check_lines_equal(char **pattern, int x, int y);
int		check_columns_equal(char **pattern, int x, int y);
int		rush_corners(int *types);
int		validate_rush(char **pattern, int x, int y);

#endif
