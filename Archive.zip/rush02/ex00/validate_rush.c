/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validate_rush.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jvuorenm <jvuorenm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/16 18:29:57 by jvuorenm          #+#    #+#             */
/*   Updated: 2022/07/16 19:17:05 by jvuorenm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "rush2_header.h"

int	check_corners(int *types, int x, int y)
{
	if (cornertypes_consistent(types, x, y) == 0)
		return (0);
	return (1);
}

int	check_lines_equal(char **pattern, int x, int y)
{
	int	i;

	i = 0;
	if (x == 0 || y == 0)
		return (1);
	while (i < y)
	{
		if ((ft_strlen(pattern[i]) - 2) != x)
		{
			return (0);
		}
		i++;
	}
	return (1);
}

int	validate_rush(char **pattern, int x, int y)
{
	int		*pt_type;

	if (ft_strlen(pattern[0]) == 0)
		return (0);
	pt_type = create_corner_arr(pattern, x, y);
	if (check_corners(pt_type, x, y) == 0)
		return (0);
	if (check_lines_equal(pattern, x, y) == 0)
		return (0);
	return (1);
}
