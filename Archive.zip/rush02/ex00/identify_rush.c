/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   identify_rush.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jvuorenm <jvuorenm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 12:29:57 by jvuorenm          #+#    #+#             */
/*   Updated: 2022/07/17 13:01:05 by jvuorenm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "rush2_header.h"

int	identify_rush(char **pattern, int x, int y)
{
	int	*type;
	int	multiple;

	multiple = 0;
	type = create_corner_arr(pattern, x, y);
	if (rush00_corners(type, x, y) == 1)
		print_rush_result("rush-00", x + 1, y + 1, multiple++);
	if (rush01_corners(type, x, y) == 1)
		print_rush_result("rush-01", x + 1, y + 1, multiple++);
	if (rush02_corners(type, x, y) == 1)
		print_rush_result("rush-02", x + 1, y + 1, multiple++);
	if (rush03_corners(type, x, y) == 1)
		print_rush_result("rush-03", x + 1, y + 1, multiple++);
	if (rush04_corners(type, x, y) == 1)
		print_rush_result("rush-04", x + 1, y + 1, multiple++);
	return (0);
}

void	print_rush_result(char *rush_name, int x, int y, int multiple)
{
	if (multiple > 0)
		ft_putstr(" || ");
	ft_putstr("[");
	ft_putstr(rush_name);
	ft_putstr("]");
	ft_putstr(" [");
	ft_putnbr(x);
	ft_putstr("]");
	ft_putstr(" [");
	ft_putnbr(y);
	ft_putstr("]");
}

int	*create_corner_arr(char **pattern, int x, int y)
{
	int		*types;
	int		i;
	char	*cornertypes;

	cornertypes = "o/\\AC";
	types = malloc (sizeof (int) * 5);
	i = 0;
	while (i < 5)
	{
		if (pattern[0][0] == cornertypes[i])
			*(types) = i;
		if (pattern[0][x] == cornertypes[i])
			*(types + 1) = i;
		if (pattern[y][0] == cornertypes[i])
			*(types + 2) = i;
		if (pattern[y][x] == cornertypes[i])
			*(types + 3) = i;
		i++;
	}
	return (types);
}

int	cornertypes_consistent(int *types, int x, int y)
{
	int	i;
	int	sum;

	sum = 0;
	i = 0;
	if (x == 0)
		sum += *(types) + *(types + 2);
	else if (y == 0)
	{
		sum += *(types) + *(types + 1);
	}
	else
	{
		while (i < 4)
		{
			sum += *(types + i);
			i++;
		}
	}
	if (sum == 0 || sum == 6 || sum == 14 || sum == 4)
		return (1);
	if (sum == 3 || sum == 12 || sum == 2 || sum == 1 || sum == 7)
		return (1);
	return (0);
}
