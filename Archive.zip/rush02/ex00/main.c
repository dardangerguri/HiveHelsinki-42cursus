/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jvuorenm <jvuorenm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/16 18:29:57 by jvuorenm          #+#    #+#             */
/*   Updated: 2022/07/19 11:08:58 by dgerguri         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdlib.h>
#include "rush2_header.h"
#define MAX_STR_SIZE 32
#define BUFF_SIZE 4096

int	main(void)
{
	char	buffer[BUFF_SIZE + 1];
	char	**pattern;
	int		i;
	int		y;
	int		x;

	pattern = malloc(sizeof(char *) * BUFF_SIZE);
	pattern = allocate_memory(pattern);
	i = 0;
	while (ft_fgets(buffer, BUFF_SIZE))
	{
		ft_strcpy(buffer, pattern[i]);
		i++;
	}
	y = i - 1;
	x = get_x(pattern[0]);
	if (validate_rush(pattern, x, y) == 0)
	{
		ft_putstr("none\n");
		return (-1);
	}
	identify_rush(pattern, x, y);
	ft_putstr("\n");
	free(pattern);
	return (0);
}

char	**allocate_memory(char **pattern)
{	
	int	i;

	i = 0;
	while (i < BUFF_SIZE)
	{
		pattern[i] = malloc(sizeof(char *) * BUFF_SIZE);
		i++;
	}
	i = 0;
	return (pattern);
}

int	get_x(char *pattern)
{
	int	x;

	x = ft_strlen(pattern)-2;
	return (x);
}

void	print_pattern(int y, char **pattern)
{
	int	i;

	i = 0;
	while (i < y)
	{	
		ft_putstr(pattern[i]);
		i++;
	}
}
