/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   identify_rush_2.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jvuorenm <jvuorenm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/17 12:29:57 by jvuorenm          #+#    #+#             */
/*   Updated: 2022/07/17 13:01:05 by jvuorenm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "rush2_header.h"

int	rush00_corners(int *type, int x, int y)
{
	if ((x == 0 || y == 0) && (*(type) == 0))
		return (1);
	else if (*(type + 0) != 0)
		return (0);
	else if (*(type + 1) != 0)
		return (0);
	else if (*(type + 2) != 0)
		return (0);
	else if (*(type + 3) != 0)
		return (0);
	else
		return (1);
	return (1);
}

int	rush01_corners(int *type, int x, int y)
{
	if ((x == 0 || y == 0) && (*(type) == 1))
		return (1);
	else if (*(type) != 1)
		return (0);
	else if (*(type + 1) != 2)
		return (0);
	else if (*(type + 2) != 2)
		return (0);
	else if (*(type + 3) != 1)
		return (0);
	else
		return (1);
	return (1);
}

int	rush02_corners(int *type, int x, int y)
{
	if ((x == 0 || y == 0) && (*(type) == 3))
		return (1);
	else if (*(type) != 3)
		return (0);
	else if (*(type + 1) != 3)
		return (0);
	else if (*(type + 2) != 4)
		return (0);
	else if (*(type + 3) != 4)
		return (0);
	else
		return (1);
	return (1);
}

int	rush03_corners(int *type, int x, int y)
{
	if ((x == 0 || y == 0) && (*(type) == 3))
		return (1);
	else if (*(type) != 3)
		return (0);
	else if (*(type + 1) != 4)
		return (0);
	else if (*(type + 2) != 3)
		return (0);
	else if (*(type + 3) != 4)
		return (0);
	else
		return (1);
	return (1);
}

int	rush04_corners(int *type, int x, int y)
{
	if ((x == 0 || y == 0) && (*(type) == 3))
		return (1);
	else if (*(type) != 3)
		return (0);
	else if (*(type + 1) != 4)
		return (0);
	else if (*(type + 2) != 4)
		return (0);
	else if (*(type + 3) != 3)
		return (0);
	else
		return (1);
	return (1);
}
