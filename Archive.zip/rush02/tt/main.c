/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akurusio <akurusio@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/02 14:28:28 by akurusio          #+#    #+#             */
/*   Updated: 2022/07/03 12:13:35 by akurusio         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
void	ft_putchar(char c);
void	rush(int x, int y);
int		ft_atoi(char *str);

int	main(int argc, char **argv)
{
	rush(ft_atoi(argv[1]), ft_atoi(argv[2]));
	return (0);
}
