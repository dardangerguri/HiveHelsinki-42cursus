/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dgerguri <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/07 09:57:59 by dgerguri          #+#    #+#             */
/*   Updated: 2022/07/07 20:51:29 by dgerguri         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	index;

	index = 0;
	while (str[index] != '\0')
	{	
		index++;
	}
	return (index);
}

char	*ft_strdup(char *src)
{
	char	*duplicated;
	int		d;

	d = 0;
	duplicated = malloc(sizeof(duplicated) * ft_strlen(src) + 1);
	while (src[d] != '\0')
	{
		duplicated[d] = src[d];
		d++;
	}
	return (duplicated);
}
