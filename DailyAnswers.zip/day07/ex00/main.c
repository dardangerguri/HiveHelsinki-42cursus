#include <stdio.h>

char *ft_strdup(char *src);

int main(void)
{
	char *d;

char *src = "Hive";
d = ft_strdup(src);
printf("%s", d);
return (0);
}

