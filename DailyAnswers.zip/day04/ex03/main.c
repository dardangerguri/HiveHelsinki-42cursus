#include <stdio.h>

int ft_recursive_power(int nb, int power);
int main()
{
	int n;
	n = ft_recursive_power(0, 2);
	printf("%d\n", n);
}
