#include <stdio.h>

int ft_recursive_factorial(int nb);
int main()
{
int n;

n = ft_recursive_factorial(4);
printf("%d\n", n);
return (0);
}
