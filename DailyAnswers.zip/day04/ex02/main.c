#include <stdio.h>

int ft_iterative_power(int nb, int power);
int main()
{
int n;
n = ft_iterative_power(2, 5);
printf("%d\n", n);
}
