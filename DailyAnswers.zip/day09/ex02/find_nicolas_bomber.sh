cat $1 | grep -i "nicolas\tbomber\|bomber\tnicolas" | tr '\t' '\n ' | grep ".*-"
