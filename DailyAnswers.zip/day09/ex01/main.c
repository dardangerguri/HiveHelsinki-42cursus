void ft_takes_place(int hour);

int main()
{
ft_takes_place(34);
ft_takes_place(18);
ft_takes_place(19);
ft_takes_place(20);
ft_takes_place(21);
ft_takes_place(22);
ft_takes_place(23);
ft_takes_place(0);
ft_takes_place(1);
ft_takes_place(2);
ft_takes_place(3);
ft_takes_place(4);
ft_takes_place(5);
return (0);
}
