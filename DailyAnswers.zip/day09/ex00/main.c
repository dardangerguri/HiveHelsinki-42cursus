#include <unistd.h>

void	ft_generic(void);

int	main()
{
ft_generic();
return (0);
}
