/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_create_node.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dgerguri <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 19:36:57 by dgerguri          #+#    #+#             */
/*   Updated: 2022/07/15 22:02:50 by dgerguri         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h" 

t_btree	*btree_create_node(void *item)
{
	t_btree	*blist;

	blist = malloc(sizeof(t_btree));
	if (blist != NULL)
	{
		blist->left = NULL;
		blist->right = NULL;
		blist->item = item;
	}
	return (blist);
}
