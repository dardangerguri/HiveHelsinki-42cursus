#include <stdlib.h>
#include <stdio.h>

#include "ft_btree.h"

t_btree *btree_create_node(void *item);

void print(t_btree *root)
{
	if (root == NULL)
	{
		printf("---<empty>--\n");
		return;
	}
	printf("%s\n", root->item);
	printf("left ");
	print(root->left);
	printf("right ");
	print(root->right);
	printf("done\n");
}

int	main()
{
    

	t_btree *n1 = btree_create_node("a");
	t_btree *n2 = btree_create_node("b");
	t_btree *n3 = btree_create_node("c");
	t_btree *n4 = btree_create_node("d");
	t_btree *n5 = btree_create_node("e");

	n1->left = n2;
	n1->right = n3;
	n3->left = n4;
	n3->right = n5;

	print(n1);
}
