#include <stdio.h>
#include <stdlib.h>
#include "ft_list.h"

int	main()
{
	char data[] = "Hive";
	t_list *tmp;

	tmp = ft_create_elem(data);
	printf("%s", tmp->data);
}
