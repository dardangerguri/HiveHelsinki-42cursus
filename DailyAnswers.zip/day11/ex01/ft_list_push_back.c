/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_push_back.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dgerguri <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/13 16:36:23 by dgerguri          #+#    #+#             */
/*   Updated: 2022/07/13 18:31:02 by dgerguri         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

void	ft_list_push_back(t_list **begin_list, void *data)
{
	t_list	*new;

	new = *begin_list;
	if (begin_list)
	{
		while (new->next != 0)
		{
			new = new->next;
		}
		new->next = ft_create_elem(data);
	}
	else
		*begin_list = ft_create_elem(data);
}
