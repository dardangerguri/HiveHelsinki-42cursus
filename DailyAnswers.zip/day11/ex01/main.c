#include <stdio.h>
#include <stdlib.h>
#include "ft_list.h"

void	ft_list_push_back(t_list **begin_list, void *data);

int	main()
{
	t_list **head;
	t_list *headl;

	t_list n;

	n.data = "HIVE ";
	headl = &n;
	head = &headl;
ft_list_push_back(head, "Hive");

while (headl != NULL)
{
	printf("%s", headl->data);
	headl = headl->next;
}
return (0);
}
