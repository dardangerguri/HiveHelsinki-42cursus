#include <stdio.h>
#include <stdlib.h>

int    *ft_map(int *tab, int length, int(*f)(int));

int mapfun(int a)
{
if (a >= 42 )
	{
  		return (1);
	}
return(0);
}

int main()
{
	int *a;
	int i;

	i = 0;
	a = malloc(sizeof(a) * 6);
	int tab[] = {3, 43, 4, 45, 6, 67}; 
    a = ft_map(tab, 6, &mapfun);
	while (i < 6)
	printf("%d", a[i++]);
	return(0);
}
