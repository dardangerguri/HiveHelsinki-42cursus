#include <stdlib.h>
#include <stdio.h>

int	ft_count_if(char **tab, int(*f)(char*));

int mapfun(char *s)
{
	int i;
	
	i=0;
while (s[i] != '\0')
	{
 		if  (s[i] == 'd')
  		return (1);
 		i++;
	}
 return (0);
}

int main(int argc, char **argv)
{

	argc = 0;
//	char *tab[] = {"fghf", "ghfh"};
	printf("%d", ft_count_if(argv, &mapfun));
	return(0);
}
