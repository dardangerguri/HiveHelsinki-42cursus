#include <unistd.h> 

void ft_putnbr(int nb);

void  ft_putchar(char c)
{
write(1, &c, 1);
}

int main()
{
int str1 = -34342;
ft_putnbr(str1);
ft_putchar('\n');
return (0);
}

