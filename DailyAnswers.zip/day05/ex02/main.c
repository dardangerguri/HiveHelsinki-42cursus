#include <unistd.h>
#inlcude <stdio.h>
#inlcude <stdlib.h>

void ft_atoi(char *str);

int main()
{
	int number;
char str1[] = "-3456";
number = ft_atoi(str1);
printf ("%d ", number);
return (0);
}

