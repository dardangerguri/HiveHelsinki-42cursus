void ft_putchar(char c);

int	main()
{
ft_putchar('H');
ft_putchar('\n');
return (0);
}
