#include <stdio.h>

void ft_swap(int *a, int *b);

int	main()
{
int a = 55;
int b = 7;
int *ca = &a;
int *cb = &b;

printf("%d, %d\n", a, b);
ft_swap(ca, cb);
printf("%d, %d\n", a, b);

return (0);
}
