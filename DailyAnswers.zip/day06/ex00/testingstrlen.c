#include <unistd.h>
#include <stdio.h>
#include <string.h>

int	ft_strlen(char *str);
void ft_putchar(char c)
{
write(1, &c, 1);
}

int	main ()
{
int l;

char str1[] = "HIVE";
l = ft_strlen(str1);
printf("%d", l);
return (0);
}

