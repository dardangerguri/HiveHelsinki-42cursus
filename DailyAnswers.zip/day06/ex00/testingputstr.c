#include <unistd.h>

void	ft_putstr(char *str);

void ft_putchar(char c)
{
	write(1, &c, 1);
}

int	main ()
{
char str1[] = "Hi there!";
ft_putstr(str1);
ft_putchar('\n');
return (0);
}
