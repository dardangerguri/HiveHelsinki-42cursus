#include <unistd.h>
#include <stdio.h>
#include <string.h>

int	ft_strcmp(char *s1, char *s2);

void ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int	index;

	index = 0;
	while (str[index] != '\0')
	{
		ft_putchar(str[index]);
		index++;
	}
}

int	main ()
{
int c;
char str1[] = "ab";
char str2[] = "ab";
ft_putstr(str1);
ft_putchar('\n');
ft_putstr(str2);
ft_putchar('\n');
c = ft_strcmp(str1, str2);
printf("%d\n", strcmp(str1, str2));
printf("%d", c);
return (0);
}

